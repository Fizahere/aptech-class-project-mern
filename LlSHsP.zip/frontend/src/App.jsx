import axios from "axios";
import { useFormik } from "formik"

export default function App() {

  const formik = useFormik(
    {
      initialValues: {
        username: '',
        password: ''
      },
      onSubmit: (values) => {
        async function send_data() {
          try {
            const response = await axios.post("http://localhost:5000/api/auth/login", values);
            localStorage.setItem("token", response.data.token);
          } catch (error) {
            console.log(error.message)
          }
        }
        send_data();
      }
    }
  );

  async function check_login(){
    try {
      const token = localStorage.getItem("token")
      const response = await axios.get("http://localhost:5000/api/auth/protected", {
        headers:{
          Authorization: token
        }
      });
      alert(JSON.stringify(response.data))
    } catch (error) {
      alert(JSON.stringify(error.message))
    }
  }

  return (
    <div>
      <form onSubmit={formik.handleSubmit}>
        <input type="text" name="username" onChange={formik.handleChange} value={formik.values.username} />
        <input type="password" name="password" onChange={formik.handleChange} value={formik.values.password} />
        <input type="submit" value={'Sign In'} />
      </form>

      <button onClick={check_login}>Check Login Status</button>
    </div>
  )
}