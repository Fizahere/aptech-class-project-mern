import express from "express";
import cors from 'cors';
import mongoose from 'mongoose';
import { studentRouter } from './routes/studentRoutes';
import { facultyRouter } from "./routes/facultyRoutes";
import { authRouter } from "./routes/authRoutes";

async function connect_db(){
    try {
        await mongoose.connect("mongodb://127.0.0.1:27017/aptech")
        console.info("connected to mongodb")
    } catch (error) {
        console.error(error.message)
    }
}
connect_db();

const app = express()
app.use(cors())
app.use(express.json())

app.use("/api/students", studentRouter);
app.use("/api/faculties", facultyRouter);
app.use("/api/auth", authRouter);

app.listen(5000, () => {
    console.log("server running")
})